THE BADDIES — WEBSITE + ONLINE SHOPBEHEER
========================================

WAT ZIT ERIN?
- index.html: website met jullie foto's, shop, Over ons en galerij.
- Website aanpassen: teksten, prijzen en foto's wijzigen.
- Shopstatus: shop open/dicht zetten. Home en Over ons blijven altijd zichtbaar.
- server.js: server-side shopstatus, beheerlogin en voorbereid Mollie-betaalproces.
- ONLINE-CHECKLIST.txt: korte livegang-checklist.

BELANGRIJK
- De echte betaalfunctie werkt pas nadat hosting, BASE_URL en een Mollie API-sleutel zijn ingesteld.
- Gebruik eerst de Mollie TEST API key. Zet pas live als alle instellingen en tests kloppen.
- De server slaat de instellingen en bestellingen op in de map data/. Kies hosting met persistente opslag.
- De shop-aan/uit-instelling wordt op de server gecontroleerd bij elke nieuwe betaalpoging.
- Bestellingen en klantgegevens worden in data/orders.json opgeslagen. Beperk toegang tot deze bestanden en volg de privacyregels.
- Deze basis verstuurt nog geen automatische bestel- of verzendmails en berekent geen verzendkosten. Regel dit vóór echte verkoop.
- Omdat het om echte verkoop en betalingen gaat, laat een ouder/voogd of andere verantwoordelijke volwassene de betaalrekening, voorwaarden en livegang controleren.

LOKAAL TESTEN
1. Installeer Node.js 20 of nieuwer.
2. Open een terminal in deze map.
3. Voer uit: npm install
4. Kopieer .env.example naar .env en vul lokale testinstellingen in.
5. Voer uit: npm start
6. Open http://localhost:3000

ONLINE INSTELLEN
1. Kies een hostingdienst die Node.js ondersteunt en een persistente data-map/volume heeft.
2. Upload de volledige map/repository en stel de startopdracht in op: npm start
3. Stel als environment variables/secrets in:
   NODE_ENV=production
   BASE_URL=https://jouwdomein.be
   ADMIN_PASSWORD=een-lang-uniek-wachtwoord
   SESSION_SECRET=een-lange-willekeurige-geheime-waarde
   MOLLIE_API_KEY=test_... (eerst de TEST-sleutel)
4. Koppel je domein en HTTPS. BASE_URL moet exact de openbare HTTPS-URL zijn.
5. Open https://jouwdomein.be/api/health; je hoort {"ok":true,...} te zien.
6. Open de website, klik onderaan op Website aanpassen, log in met ADMIN_PASSWORD en test de shopstatus. Wijzigingen worden dan online opgeslagen.
7. Maak een testbestelling. Controleer de terugkeerpagina en /api/order-status. Test mislukte en geslaagde betalingen.
8. Stel in Mollie je websiteprofiel in en activeer Bancontact en creditcards waar beschikbaar.
9. Controleer verzendkosten, contactgegevens, retourbeleid, privacyverklaring, algemene voorwaarden, belastingen en bestelbevestigingen.
10. Laat een verantwoordelijke volwassene de live betaalrekening/identiteitscontrole en juridische details afronden. Vervang pas daarna de TEST-sleutel door de LIVE-sleutel.

BEVEILIGING
- Deel de API-sleutel of het beheerderswachtwoord nooit in chat, in de websitecode of in een openbare repository.
- Zet geheimen alleen als server environment variables/secrets.
- Gebruik een uniek, sterk ADMIN_PASSWORD en SESSION_SECRET.
- Bewaar de data-map veilig en zorg voor back-ups; ze bevat bestellingen en persoonsgegevens.
