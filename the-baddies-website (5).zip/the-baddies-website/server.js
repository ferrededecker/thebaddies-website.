'use strict';

const express = require('express');
const session = require('express-session');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = String(process.env.BASE_URL || '').replace(/\/$/, '');
const DATA_DIR = path.join(__dirname, 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'site-config.json');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');

fs.mkdirSync(DATA_DIR, { recursive: true });
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: false, limit: '2mb' }));
app.use(session({
  name: 'baddies_admin',
  secret: process.env.SESSION_SECRET || crypto.randomBytes(48).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'strict',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 12 * 60 * 60 * 1000
  }
}));

const DEFAULT_CONFIG = {
  shopOpen: true,
  brand: 'Baddies',
  teeName: 'The Baddies Tee',
  teePrice: 24.99,
  hoodieName: 'The Baddies Hoodie',
  hoodiePrice: 49.99
};

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return fallback; }
}
function writeJson(file, value) {
  const temp = `${file}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(value, null, 2), { mode: 0o600 });
  fs.renameSync(temp, file);
}
function readConfig() {
  return { ...DEFAULT_CONFIG, ...readJson(CONFIG_FILE, {}) };
}
function readOrders() { return readJson(ORDERS_FILE, {}); }
function cleanText(value, max = 200) {
  return String(value == null ? '' : value).replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, max);
}
function money(value) { return Number(Number(value).toFixed(2)); }
function adminRequired(req, res, next) {
  if (req.session && req.session.isAdmin === true) return next();
  return res.status(401).json({ error: 'Log in als beheerder om dit aan te passen.' });
}
function constantTimeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
async function mollieRequest(url, options = {}) {
  const key = process.env.MOLLIE_API_KEY;
  if (!key) throw new Error('MOLLIE_NOT_CONFIGURED');
  const response = await fetch(url, {
    ...options,
    headers: {
      Authorization: `Bearer ${key}`,
      Accept: 'application/json',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.detail || data.title || 'De betaalprovider kon de aanvraag niet verwerken.');
    error.status = response.status;
    throw error;
  }
  return data;
}
async function refreshOrderPayment(orderId, paymentId) {
  const payment = await mollieRequest(`https://api.mollie.com/v2/payments/${encodeURIComponent(paymentId)}`);
  const orders = readOrders();
  if (orders[orderId]) {
    orders[orderId].paymentStatus = payment.status || 'open';
    orders[orderId].updatedAt = new Date().toISOString();
    writeJson(ORDERS_FILE, orders);
  }
  return payment;
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'the-baddies-website' }));
app.get('/api/site-config', (_req, res) => {
  const config = readJson(CONFIG_FILE, {});
  res.set('Cache-Control', 'no-store');
  res.json({ config });
});

let loginAttempts = new Map();
app.post('/api/admin/login', (req, res) => {
  const ip = req.ip || 'unknown';
  const now = Date.now();
  const attempts = (loginAttempts.get(ip) || []).filter(t => now - t < 15 * 60 * 1000);
  if (attempts.length >= 10) return res.status(429).json({ error: 'Te veel pogingen. Probeer later opnieuw.' });
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return res.status(503).json({ error: 'Beheerwachtwoord is nog niet ingesteld op de server.' });
  if (!constantTimeEqual(req.body && req.body.password || '', expected)) {
    attempts.push(now); loginAttempts.set(ip, attempts);
    return res.status(401).json({ error: 'Onjuist wachtwoord.' });
  }
  loginAttempts.delete(ip);
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Inloggen is niet gelukt.' });
    req.session.isAdmin = true;
    req.session.save(saveErr => {
      if (saveErr) return res.status(500).json({ error: 'Sessie opslaan is niet gelukt.' });
      res.json({ ok: true });
    });
  });
});
app.post('/api/admin/logout', adminRequired, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.put('/api/admin/site-config', adminRequired, (req, res) => {
  const config = req.body && req.body.config;
  if (!config || typeof config !== 'object' || Array.isArray(config)) return res.status(400).json({ error: 'Ongeldige website-instellingen.' });
  const safe = { ...config, shopOpen: config.shopOpen !== false };
  for (const key of ['teePrice', 'hoodiePrice']) {
    const value = Number(safe[key]);
    if (!Number.isFinite(value) || value < 0 || value > 9999) return res.status(400).json({ error: `Ongeldige prijs voor ${key}.` });
    safe[key] = money(value);
  }
  writeJson(CONFIG_FILE, safe);
  res.json({ ok: true, config: safe });
});

app.post('/api/create-payment', async (req, res) => {
  try {
    const config = readConfig();
    if (config.shopOpen === false) return res.status(403).json({ error: 'De shop is tijdelijk gesloten. Probeer later opnieuw.' });
    if (!BASE_URL || !/^https:\/\//i.test(BASE_URL)) return res.status(503).json({ error: 'De website-URL is nog niet ingesteld. Betalen is nog niet beschikbaar.' });
    if (!process.env.MOLLIE_API_KEY) return res.status(503).json({ error: 'De betaalprovider is nog niet ingesteld.' });

    const customerIn = req.body && req.body.customer || {};
    const customer = {
      name: cleanText(customerIn.name, 120),
      email: cleanText(customerIn.email, 190),
      street: cleanText(customerIn.street, 190),
      postalCode: cleanText(customerIn.postalCode, 20),
      city: cleanText(customerIn.city, 100)
    };
    if (!customer.name || !/^\S+@\S+\.\S+$/.test(customer.email) || !customer.street || !customer.postalCode || !customer.city) {
      return res.status(400).json({ error: 'Vul alle geldige contact- en verzendgegevens in.' });
    }
    const itemsIn = Array.isArray(req.body && req.body.items) ? req.body.items : [];
    if (!itemsIn.length || itemsIn.length > 20) return res.status(400).json({ error: 'Je winkelmandje is leeg of bevat te veel regels.' });
    const catalog = {
      tee: { name: cleanText(config.teeName || DEFAULT_CONFIG.teeName, 100), price: money(config.teePrice ?? DEFAULT_CONFIG.teePrice) },
      hoodie: { name: cleanText(config.hoodieName || DEFAULT_CONFIG.hoodieName, 100), price: money(config.hoodiePrice ?? DEFAULT_CONFIG.hoodiePrice) }
    };
    const items = [];
    for (const raw of itemsIn) {
      const productId = raw && raw.productId;
      const size = String(raw && raw.size || '');
      const quantity = Number(raw && raw.quantity);
      if (!catalog[productId] || !['S', 'M', 'L', 'XL'].includes(size) || !Number.isInteger(quantity) || quantity < 1 || quantity > 10) {
        return res.status(400).json({ error: 'Een product, maat of aantal is ongeldig.' });
      }
      items.push({ productId, name: catalog[productId].name, size, quantity, unitPrice: catalog[productId].price, lineTotal: money(catalog[productId].price * quantity) });
    }
    const total = money(items.reduce((sum, item) => sum + item.lineTotal, 0));
    if (total <= 0) return res.status(400).json({ error: 'Het bestelbedrag moet hoger zijn dan nul.' });
    const orderId = crypto.randomUUID();
    const orders = readOrders();
    orders[orderId] = { id: orderId, customer, items, total, currency: 'EUR', paymentStatus: 'creating', createdAt: new Date().toISOString() };
    writeJson(ORDERS_FILE, orders);

    const payment = await mollieRequest('https://api.mollie.com/v2/payments', {
      method: 'POST',
      body: JSON.stringify({
        amount: { currency: 'EUR', value: total.toFixed(2) },
        description: `The Baddies bestelling ${orderId.slice(0, 8)}`,
        redirectUrl: `${BASE_URL}/?payment=return&order=${encodeURIComponent(orderId)}`,
        webhookUrl: `${BASE_URL}/api/mollie-webhook`,
        metadata: { orderId }
      })
    });
    const updatedOrders = readOrders();
    updatedOrders[orderId].molliePaymentId = payment.id;
    updatedOrders[orderId].paymentStatus = payment.status || 'open';
    writeJson(ORDERS_FILE, updatedOrders);
    const checkoutUrl = payment && payment._links && payment._links.checkout && payment._links.checkout.href;
    if (!checkoutUrl) return res.status(502).json({ error: 'De betaalprovider heeft geen afrekenlink teruggegeven.' });
    res.json({ checkoutUrl, orderId });
  } catch (error) {
    if (error.message === 'MOLLIE_NOT_CONFIGURED') return res.status(503).json({ error: 'De betaalprovider is nog niet ingesteld.' });
    console.error('Payment creation failed:', error.message);
    res.status(error.status && error.status < 500 ? 400 : 502).json({ error: 'De betaling kon niet worden gestart. Probeer het later opnieuw.' });
  }
});

app.post('/api/mollie-webhook', async (req, res) => {
  const paymentId = cleanText(req.body && req.body.id, 100);
  if (!paymentId || !process.env.MOLLIE_API_KEY) return res.sendStatus(200);
  try {
    const payment = await mollieRequest(`https://api.mollie.com/v2/payments/${encodeURIComponent(paymentId)}`);
    const orderId = payment && payment.metadata && payment.metadata.orderId;
    if (orderId) {
      const orders = readOrders();
      if (orders[orderId]) {
        orders[orderId].paymentStatus = payment.status || 'open';
        orders[orderId].updatedAt = new Date().toISOString();
        writeJson(ORDERS_FILE, orders);
      }
    }
  } catch (error) { console.error('Mollie webhook update failed:', error.message); }
  res.sendStatus(200);
});

app.get('/api/order-status/:orderId', async (req, res) => {
  const orderId = cleanText(req.params.orderId, 80);
  const orders = readOrders();
  const order = orders[orderId];
  if (!order) return res.status(404).json({ error: 'Bestelling niet gevonden.' });
  if (order.molliePaymentId && process.env.MOLLIE_API_KEY) {
    try { const payment = await refreshOrderPayment(orderId, order.molliePaymentId); return res.json({ status: payment.status || order.paymentStatus }); }
    catch (error) { console.error('Order status check failed:', error.message); }
  }
  res.json({ status: order.paymentStatus || 'open' });
});

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'API-route niet gevonden.' });
  res.set('Cache-Control', 'no-store');
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`The Baddies website draait op poort ${PORT}`);
  if (!process.env.ADMIN_PASSWORD) console.warn('Waarschuwing: ADMIN_PASSWORD ontbreekt; online bewerken blijft uitgeschakeld.');
  if (!process.env.MOLLIE_API_KEY) console.warn('MOLLIE_API_KEY ontbreekt; betalingen blijven uitgeschakeld.');
});
